require.config({
	baseUrl: 'js',
	paths: {
		"jquery": "lib/jquery-1.11.3",
		"jquery.cookie":"plug/jquery.cookie",
		"zhuce":"js/zhuce",
		"denglu":"js/denglu",
		"shouyecookie":"js/shouyecookie",
		"indexjson":"js/indexjson",
		"template":"plug/template",
		"louceng":"js/louceng",
		"layer":"plug/layer/layer",
		"jquery.fly":"plug/jquery.fly"
	},
	//处理非AMD规范
	shim:{
		"jquery.cookie":['jquery'],
		"template":['jquery'],
		"jquery.fly":['jquery']
	}
});