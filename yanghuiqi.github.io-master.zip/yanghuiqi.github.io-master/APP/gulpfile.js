var gulp = require('gulp');

//编译sass 和压缩 
var css = require('gulp-sass-china'),
	notify = require('gulp-notify'),
    plumber = require('gulp-plumber');
gulp.task('cssMin',function(){
	gulp.src('src/sass/*.{scss,sass}')
		.pipe(plumber({
			errorHandler: notify.onError('Error: <%= error.message %>')
		 }))
		.pipe( css({
			outputStyle: 'expanded' }))
		.pipe( gulp.dest('src/css') );
});

gulp.task('scss',function(){
	gulp.watch('src/sass/*.{scss,sass}',['cssMin']);
});
//服务器
var connect = require('gulp-connect');
gulp.task('server',function(){
	connect.server({
		root: 'src',  
		livereload: true 
	});
});
//刷新
gulp.task('watch',function(){
	gulp.watch(['src/*.html','src/css/*.css','src/js/*'],function(){
		//改变的时候 刷新
		gulp.src('src/login.html').pipe( connect.reload() );
	})
});
gulp.task('server-watch',['server','watch','scss']);
