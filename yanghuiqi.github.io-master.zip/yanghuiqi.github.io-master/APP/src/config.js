require.config({
	baseUrl: 'js',
	paths: {
		"jquery": "lib/jquery-1.11.3",
		"iscroll":"lib/iscroll",
		"rem":"lib/rem",
		"swiper":"lib/swiper.min",
		"zepto":"lib/zepto.min",
		"fastclick":"lib/fastclick",
		"layer":"plug/layer/layer"
	},
	//处理非AMD规范
	shim:{
		
	}
});