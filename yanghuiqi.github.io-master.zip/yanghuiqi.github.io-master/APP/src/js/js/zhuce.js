
require(['../../config'],function(){

	//核心工作
	require(['jquery'],function($){
	
	//变量
	var username=$('.username'),
		password=$('.password'),
		btn=$('.reg');
		//用户名验证
		var regUname = /^[a-zA-Z_]\w{5,15}$/;
		username.blur(function(){
			var uname = username.val();
			//判断用户名是否合法
			if(!regUname.test(uname)){
				alert('用户名不合法');
				return;
			}

		});
		//密码
		var regPsw=/^[a-zA-Z_]\w{5,15}$/;
		password.blur(function(){
			var pvalue=password.val();
			//假设成功
			if(!regPsw.test(pvalue)){
				alert('密码不合法');
				return;
			}
		});
		
		btn.click(function(){
			$.ajax({
				type: 'post',
				url: 'https://datainfo.duapp.com/shopdata/userinfo.php',
				data: {
					status:'register',
					userID: username.val(),
					password: password.val()
				},
				success: function(result){
					if(result==1){
						alert("注册成功");
						window.location.href="login.html";
					}
					

				}
			});
		});
	});
});
