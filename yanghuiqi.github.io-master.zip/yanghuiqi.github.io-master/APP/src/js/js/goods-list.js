require(['../../config'],function(){

	//加载需要用到的模块
	require(['zepto','iscroll'],function(zepto,IScroll){
		
		var myScroll = new IScroll(".scroll-wrapper",{
		 	scrollbars:true, /*是否显示滚动条*/
	        shrinkScrollbars: 'scale', /*滚动条弹性*/
	        fadeScrollbars: true,/*自动隐藏滚动条*/
	        click:true/*内容可以点击*/
		});
		
		var common = {
		
		    loading:null,
		    showLoading:function () {
		        /* loading只有一个； 单例*/
		        if(this.loading){
		            /*有的话直接显示*/
		            this.loading.show()
		        }else {
		            /*没有就创建*/
		            this.loading = $("<div id='loading'>loading</div>");
		            this.loading.appendTo(document.body);
		        }
		
		    },
		    hideLoading:function () {
		        this.loading.hide()
		    }
		
		};
		
		var classID = 0; //默认的分类id
	    var pageCode=0;
	    var linenumber =6;
		var aData=[];
		var $classList = $(".class-list");
		var $proList = $(".pro-list ul");
		
		function getClassData() {
          $.get("https://datainfo.duapp.com/shopdata/getclass.php",function (data) {
              var str1 = "";
              var data = JSON.parse(data);
              for(var i=0;i<data.length;i++){
                  str1+='<li data-id="'+data[i].classID+'">'+data[i].className+'</li>'
              }
				console.log(data[0].className)
              $(".class-list").html(str1)
          },"json")
        };
        getClassData();
		 
		
		function getData(){
			common.showLoading();
			$.getJSON("https://datainfo.duapp.com/shopdata/getGoods.php?callback=?&classID="+classID+"&pageCode="+pageCode+"&linenumber="+linenumber,function (data) {
		        var str = "";
		        console.log(data)
		        aData=data;
		        for(var i=0;i<data.length;i++){
	            	str+=`<li>
							<img src="${data[i].goodsListImg}" data-id="${data[i].goodsID}" />
							<p>${data[i].goodsName}</p>
							<p><i>￥${data[i].price}</i><span>￥99.00</span></p>
						</li>`
		        }
		        if(pageCode==0){
                    //替换数据
                    $proList.html(str);
                }else {
                    //pageCode 不是0 说明是加载更多
                    //数据拼接
                    $proList.html($proList.html()+str);
                }
		       myScroll.refresh();
		       common.hideLoading();
		   });
		};
		getData();
		
		function bindEvent() {
            /*切换分类*/
            $classList.on("click","li",function () {
               classID =  $(this).attr("data-id");
                /*把页面值0*/
                pageCode = 0;

                //分类发生改变重新获取数据
                getData();
            });

           myScroll.on("scrollEnd",function () {
                console.log(this.y);//当前值
                console.log(this.maxScrollY) //最大值
                if(this.y==this.maxScrollY){
                    //到底了，需要加载更多
                    pageCode++;
                    getData();
                }
            });
       	};
       	bindEvent();

	   
	    $(".pro-list").on("click","img",function(){
				var id = $(this).attr("data-id");
				
				var proData = {};
				for(var i=0;i<aData.length;i++){
					if(aData[i].goodsID==id){
						proData = aData[i];
						break;
					}
				};
				var proHistory = JSON.parse(localStorage.getItem("proHistory")||'[]');
				for(var i=0;i<proHistory.length;i++){
					if(proHistory[i].goodsID==id){
						proHistory.splice(i,1);
					}
				}
				proHistory.unshift(proData);
				console.log(proHistory);
				localStorage.setItem("proHistory",JSON.stringify(proHistory));
				window.location.href = "details.html?goodsID="+id;
		});

	});
});

