require(['../../config'],function(){

	//加载需要用到的模块
	require(['jquery','layer'],function(jquery,layer){
		layer.config({
		  path: 'js/plug/layer/' //layer.js所在的目录，可以是绝对目录，也可以是相对目录
		});
		var cart=function(){

			
			var userID = JSON.parse(localStorage.getItem("userID")||'[]');
			return{
				init:function(){
					this.prize();
					this.getD();
					
				},
				getData:function(){
					
					$.getJSON("https://datainfo.duapp.com/lottery/fruitsubmit.php",
						{userID:userID,fruit:0},function(data){
							if(data==0){
								layer.alert("用户已经抽过")
								return;
							}else if(data==2){
								
								
							var index=null;
							var time=setInterval(function(){
								var timer=parseInt(Math.random()*8);
								console.log(timer);
								$('.prize-item').eq(timer).addClass("active").siblings().removeClass("active");
								index=timer;
							},200);
							var arr=['Iphon7普拉斯','PPTV3D手机','PPBOX','侏罗纪T恤','乐高模型','速度与激情T恤','PPTV一年会员','100元代金券'];

							setTimeout(function(){
								clearInterval(time);
								alert("恭喜你获得"+arr[index]+"");
								$.getJSON("https://datainfo.duapp.com/lottery/fruitsubmit.php",
								{userID:userID,fruit:index},function(data){

								})
							},2000)
							
						}
							
					})
				},
				getD:function(){
					$.getJSON('https://datainfo.duapp.com/lottery/getsuerfr.php?callback=?',function(data1){
						var str='';
						
						for(var i=0;i<data1.length;i++){
							str+=`<li>
									<span class="fl">${data1[i].fruit}</span>
									<span class="over">${data1[i].userID}</span>
									<span class="fr">${data1[i].timer}</span>
								</li>`
						}

						$('.info ul').html(str);

					})
				},
				prize:function(){
					var _this=this;
					var bool=true;
					$(".c-prize").on('click',function(){
						if(bool){
							_this.getData();
							bool=false;
					}else{
						layer.alert("只有一次抽奖机会");
					}
					 
				})
							
			}

		}

	}();
		
		cart.init();
	});
});
