require(['../../config'],function(){
	//核心工作
	require(['jquery','swiper','fastclick'],function(jquery,Swiper,fastclick){

	var detail = function () {
	var goods=null;
    var $wrapper = $(".swiper-wrapper");
    var number=0;
    /*创建siwper*/
    return {
        init:function () {
        	var url = window.location.href;
		    var params = url.split("?")[1]//params:参数  (goodsID=43)
		    console.log(url);
		    var goodsID = params.split("=")[1];
		    goods=goodsID;
		    console.log(goods);
            fastclick.attach(document.body);
            this.getData();
            this.loaction();
            this.addCart();
        },
        getData:function () {
            $.getJSON("https://datainfo.duapp.com/shopdata/getGoods.php?callback=?",{goodsID:goods},function (data) {
                	
                var aImgs = JSON.parse(data[0].imgsUrl);
                
                var str = "";
                for(var i=0;i<aImgs.length;i++){
                    str+='<div class="swiper-slide"><img src="'+aImgs[i]+'"></div>'
                }
                $wrapper.html(str);

                var strr="";
                	strr+=`<p class="info-v">${data[0].goodsName}</p>
					<p class="info-v price">￥<em class="info-money">${data[0].price}</em><del class="old-p">158</del></p>
					<p class="info-v">购买人数 : <span class="shop-p">${data[0].buynumber}</span></p>`

				$('.info-text').html(strr);


                
                // swiper.update();  // 更新Swiper
                // swiper.reLoop(); // 重新对需要循环的slide个数进行计算
                var swiper = new Swiper('.swiper-container', {
                        pagination: '.my-pagination',
                        slidesPerView: 3,
                        loop:true
                });

            })
        },
        loaction:function(){
            $('.look-shop').on('click',function(){
                    window.location.href="shop-details.html?goodsID="+goods;
                    
            })
        },
        addCart:function(){
            
            var userID = JSON.parse(localStorage.getItem("userID")||'[]');
            $('.foot-add').on('click',function(){
                number++;
                $.getJSON('https://datainfo.duapp.com/shopdata/updatecar.php',
                    {userID:userID,goodsID:goods,number:1},function(data){
                        alert("添加成功");

                    })
            })
        }

    }
}();

detail.init();
	});

});
