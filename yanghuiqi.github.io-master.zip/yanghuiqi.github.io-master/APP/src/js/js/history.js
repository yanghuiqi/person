require(['../../config'],function(){

	//加载需要用到的模块
	require(['jquery'],function(jquery){
		var proHistory = JSON.parse(localStorage.getItem("proHistory"));

	        var str = "";
	        for(var i=0;i<proHistory.length-1;i++){
	            str+='<li>' +
	                    '<a href="detail.html?goodsID='+proHistory[i].goodsID+'"><img src="'+proHistory[i].goodsListImg+'"/></a>' +
	                    '<p>'+proHistory[i].goodsName+'</p>' +
	                    '<p>价格:<em>$'+proHistory[i].price+'</em></p>' +
	                '</li>'
	        }
	        $(".nav").html(str);
	});
});
