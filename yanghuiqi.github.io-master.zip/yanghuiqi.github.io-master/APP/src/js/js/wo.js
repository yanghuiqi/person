
require(['../../config'],function(){

	//核心工作
	require(['jquery'],function($){
		var user = JSON.parse(localStorage.getItem("user")||'[]');
		$('.name').html(user.userID);
		$('.pic').css("background","url("+user.userimg_url+")");
		$('.pic').css({"backgroundSize":"100%,100%","borderRadius":"15px"});

			
});
});