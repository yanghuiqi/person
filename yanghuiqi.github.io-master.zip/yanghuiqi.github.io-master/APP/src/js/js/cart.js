require(['../../config'],function(){

	//加载需要用到的模块
	require(['jquery'],function(jquery){
		var cart=function(){
			var userID = JSON.parse(localStorage.getItem("userID")||'[]');
			return{
				init:function(){
					this.getData();
					this.addCount();
					this.redu();
					this.delete();
					this.totalMoney();
				},
				savaData:function(userID,goods,number){
					$.getJSON('https://datainfo.duapp.com/shopdata/updatecar.php',
	                  {userID:userID,goodsID:goods,number:number},function(data){

	                  })

				},
				getData:function(){
					var _this=this;
					$.getJSON('https://datainfo.duapp.com/shopdata/getCar.php?callback=?',{userID:userID},function(data){
						if(data.length){
							$('.s-count-value').html(data.length);
						}else{
							$('.s-count-value').html(0);
						}
						var str="";
						for(var i=0;i<data.length;i++){
							str+=`<li data-goodsId="${data[i].goodsID}"}>
									<div class="main-img">
										<img src="${data[i].goodsListImg}">
									</div>
									<div class="main-con">
										<p class="nowrap">${data[i].goodsName}</p>
										<p>单价 :<span>￥<em class="price-c">${data[i].price}</em></span></p>
										<p class="count-value">数量 :<a href="javacript:;" class="cart-btn cart-re"></a>
											<input type="text" value="${data[i].number}" class="count-v">
											<a href="javacript:;" class="cart-btn cart-ad"></a>
										</p>
										<i class="delete"><img src="img/cart-clear.jpg"></i>
									</div>
								</li>`;

						}
						$('.main-u').html(str);
						_this.totalMoney()
						
					})
				},
				addCount:function(){
					var _this=this;
					$('body').on('click','.cart-ad',function(){
						var number=$(this).prev().val();
						var goods=$(this).parents('li').attr('data-goodsId');
						number++;
						$(this).prev().val(number);
						_this.totalMoney();
						_this.savaData(userID,goods,number);

					})
				},
				redu:function(){
					var _this=this;
					$('body').on('click','.cart-re',function(){
						var number=$(this).next().val();
						var goods=$(this).parents('li').attr('data-goodsId');
						number--;
						if(number<1)return;
						$(this).next().val(number);
						_this.totalMoney();
						_this.savaData(userID,goods,number);
					})
				},
				delete:function(){
					var _this=this;
					$('body').on('click','.delete',function(){
						if(confirm("确定删除宝贝吗？")){
							$(this).parents("li").remove();
							var sCount=$('.s-count-value').html()-1;
	                        $('.s-count-value').html(sCount);
							var goods=$(this).parents('li').attr('data-goodsId');
							$.getJSON('https://datainfo.duapp.com/shopdata/updatecar.php',
	                    		{userID:userID,goodsID:goods,number:0},function(data){
	                        	if(data==0){
	                        		alert("删除成功哦！")
	                        		

	                        	}

	                    	})
						}
					
						_this.totalMoney();

					});
				},
				totalMoney:function(){
					var money=0;
					$('.main-u li').each(function(){
						var totalM=$(this).find('.price-c').html()*$(this).find('.count-v').val();
						money+=parseFloat(totalM);
					})
					$('.s-count-total em').html(money);
				}
			}

	}();
		
		cart.init();
	});
});
