require(['../../config'],function(){
	//核心工作
	require(['jquery'],function(jquery){

	var shopdetail = function () {
	var goods=null;
    var $wrapper = $(".nav-area ul");
    /*创建siwper*/
   return {
        init:function () {
        	var url = window.location.href;
		    var params = url.split("?")[1]//params:参数  (goodsID=43)
		    
		    var goodsID = params.split("=")[1];
		    goods=goodsID;
		    this.getData();
            this.goBack();
        },
        getData:function () {
            $.getJSON("https://datainfo.duapp.com/shopdata/getGoods.php?callback=?",{goodsID:goods},function (data) {
                //info		
                var aImgs = data[0];
                var con=aImgs.detail;
                var text=con.split("。");

               	var str = "";
               	for(var i=0;i<text.length;i++){
               		 str+=`
                    	<li>${text[i]}</li>
                    `
               	}
                $wrapper.html('<li class="first"><img src="'+aImgs.goodsListImg+'"></li>'+str);


            })
        }

    }
}();

shopdetail.init();
	});

});
