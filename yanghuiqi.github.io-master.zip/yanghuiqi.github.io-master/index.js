/*
	入口文件  处理整个首页的内容
*/


//加载配置文件
require(['config'],function(){

	//核心工作
	require(['jquery','jquery.cookie','shouyecookie','template','louceng'],function($,w,r,template,f){

	$.getJSON('../json/gys.json',function(data){
		/*console.log(data);*/
		var html=template('xuanxiang',{data:data});
		$('.tianchong').html(html);


		$('.xuanxiang').mouseenter(function(){
		$(this).addClass('active').siblings().removeClass('active');
		$('.xuanxiang-item').eq($(this).index()).show().siblings().hide();
	});

	//供应商选项
	$('.gys-span').mouseenter(function(){
		// 样式动
		$(this).addClass('active');
		$(this).parent().siblings().find('.gys-span').removeClass('active');
		// 小箭头动
		$(this).siblings().show().parent().siblings().find('.gys-spani').hide();
		// 选项卡动
		var index=$(this).parent().index();
		$('.gys-item').eq(index).show().siblings().hide();
		
	});
	
	
	
	
	//lunbo
	var botUl=$('.bot-bottom ul'),
		botli=$('.bot-bottom ul li'),
		index1=0,
		timer=0;
	
	function autoPlay(){
			timer = setInterval(function(){
			index1++;
			index1 %= botli.length;
			imgSwitch();
		},2000);
	}
	function imgSwitch(){
		botUl.animate({
			'margin-top': -24*index1
		});
		
	};
	autoPlay();
	imgSwitch();

		//index轮播
		var imgWrap=$('.img-wrap img'),
			circleitem=$('.circle-item'),
			now1=0,
			next1=0,
			timer1=0;
		function autoPlay1(){
				timer1 = setInterval(function(){
				next1++;
				next1 %= imgWrap.length;
				imgSwitch1();
			},2000);
		}
		function imgSwitch1(){
			imgWrap.eq(now1).fadeTo(500,0);
			imgWrap.eq(next1).fadeTo(500,1);
			var src=imgWrap.eq(next1).attr("data-url");
			$('.bg').css({"background":src});
			now1 =next1;
			circleitem.eq(next1).addClass('active').siblings().removeClass('active');

		}
		//鼠标经过小圆圈切换图片
		circleitem.click(function(){
			next1 = $(this).index();
			imgSwitch1();
		});
		
		autoPlay1();
		imgSwitch1();
		//选项卡轮播
		var shortimg=$('.short-con.lb0 img'),
			shortItem=$('.short-circle.lo0 span'),
			shortimg1=$('.short-con.lb1 img'),
			shortItem1=$('.short-circle.lo1 span'),
			shortimg2=$('.short-con.lb2 img'),
			shortItem2=$('.short-circle.lo2 span'),
			shortimg3=$('.short-con.lb3 img'),
			shortItem3=$('.short-circle.lo3 span'),
			shortimg4=$('.short-con.lb4 img'),
			shortItem4=$('.short-circle.lo4 span'),
			shortimg5=$('.short-con.lb5 img'),
			shortItem5=$('.short-circle.lo5 span');
		/*	console.log(shortimg,shortItem);*/
		lunbo(shortimg,shortItem);
		lunbo(shortimg1,shortItem1);
		lunbo(shortimg2,shortItem2);
		lunbo(shortimg3,shortItem3);
		lunbo(shortimg4,shortItem4);
		lunbo(shortimg5,shortItem5);
		function lunbo(emem1,emem2){
			var now2=0,
				next2=0,
				timerr=0;
				function autoPlay2(){
				timerr = setInterval(function(){
				next2++;
				next2 %= emem1.length;
				imgSwitch2();
			},2000);
		}
		function imgSwitch2(){
			emem1.eq(now2).fadeTo(500,0);
			emem1.eq(next2).fadeTo(500,1);
			now2 =next2;
			emem2.eq(next2).addClass('active').siblings().removeClass('active');

		}
		autoPlay2();
		emem2.click(function(){
			next2 = $(this).index();
			imgSwitch2();
		});
		}
			
	
	});
		
	});
});
