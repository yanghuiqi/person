
require(['../../config'],function(){

	//核心工作
	require(['jquery','jquery.cookie'],function($){
	var regStatus={
		uname:false,
		psw:false,
		phone:false
	};
	$('.yanzhengma1').click(function(event){
		event.preventDefault();
		var random=parseInt(Math.random()*Math.pow(32,4));
		var v=('00000'+random.toString(16)).substr(-4);
		$(this).html(v);
	});
	$('.form-control').blur(function(){
		if($(this).val()==$('.yanzhengma1').html()){
				$('.duihao').show();
		}
	});

	// 注册选项
	$('.radio').click(function(){
		$('.introduction').eq($(this).parent('.xuanze').index()-1).show().siblings().hide();
		console.log($(this).parent('.xuanze').index());
	});
	//变量
	var account=$('.control-item .account'),
		password=$('.control-item .password'),
		phone=$('.control-item .phone'),
		helpTip=$('.help-tips.tip1'),
		helpMi=$('.mi'),
		helpPhone=$('.ptip'),
		btn1=$('.control .btn1');
		
		//用户名验证
		var regUname = /^[a-zA-Z_]\w{5,15}$/;
		account.blur(function(){
			var uname = account.val();
			//假设用户名正确
			
			regStatus.uname = true;
			if(uname==''){
				helpTip.show();
			}

			//判断用户名是否合法
			if(!regUname.test(uname)){
				console.log('用户名不合法');
				regStatus.uname = false;
				return;
			}

		
			//判断是否存在用户名
			$.ajax({
				url: 'http://10.9.151.199/PC-Project-Admin/checkAccount.php',
				data: {
					account: uname
				},
				dataType: 'jsonp',
				success: function(result){
					if(result.status){
						console.log('用户名可用');
					}else{
						console.log('用户名已存在');
						regStatus.uname = false;
					}
				}
			});
		});
		//密码
		var regPsw=/^[a-zA-Z_]\w{5,15}$/;
		password.blur(function(){
			var pvalue=password.val();
			//假设成功
			regStatus.uname=true;
			if(pvalue==''){
				helpMi.show();
			}
			if(!regPsw.test(pvalue)){
				console.log('密码不合法');
				regStatus.uname=false;
				return;
			}
		});
		//手机号验证
		var regPhone = /^1[3578]\d{9}$/; 
		phone.blur(function(){
			var phvalue = phone.val();
			regStatus.phone = true;
			if(phvalue==''){
				helpPhone.show();
			}
			
			if(!regPhone.test(phvalue)){
				console.log('手机号不合法');
				regStatus.uname=false;
				return;
			}
		});
		//点击登录
		btn1.click(function(){
			/*for(var i in regStatus){
				if(!regStatus[i]){
					console.log('数据不合法');
					return;
				}
			}*/
			$.ajax({
				type: 'post',
				url: 'http://10.9.151.199/PC-Project-Admin/register.php',
				data: {
					account: account.val(),
					password: password.val()
				},
				dataType: 'jsonp',
				success: function(result){
					console.log(result);
					if(result.status){
						console.log('注册成功');
					}else{
						console.log('注册失败');
					}
				}
			});
	});
		
			
});
});