require(['../../config'],function(){

	require(['jquery','jquery.cookie','template','layer'],function($,jquerycookie,template,layer){
		layer.config({
		  path: 'js/plug/layer/' //layer.js所在的目录，可以是绝对目录，也可以是相对目录
		});

		/*
	 	1、读取cookie   readCookie
	 	2、设置cookie   setCookie
	 	3、将cookie中的数据渲染到页面上   initData
	 	4、数量增加
	 	5、数量减少
	 	6、直接输入
	 	7、删除 (单个删除  批量删除)
	 	8、选中
	 	9、结算信息填充
		*/
		var cart={
			cart:{},//存 cookie 
			data:{},//存 json数据
			carMain:$('.cart-main-content'),
			init:function(){
				//json数据库支持
				var _this= this;
				//要想拿cart 先读cookie
				this.readCookie();
				$.getJSON('../json/data.json',function(data){
					//指定json data 把data塞进去 保留数据
					//遍历cookie 的编号 也就是几个对象
					//"10001":{
					//	id:"10000",
					//	amount:input.val();
					//}
					//给模板传入两个对象 cart  和json数据 data
					_this.data=data;
					var list=template('cart-list',{cart:_this.cart,data:data});
					_this.carMain.html(list);
				});
				//更改数量
				this.increase();
				this.decrease();
				this.input();
				//删除
				this.delete();
				this.deleteSelect();
				//选中
				this.select();
				this.selectAll();
				
			},
			increase:function(){
				var _this=this;
				//因为存在多个所以需要 事件委托 + -		
				this.carMain.on('click','.amount-increase',function(){
					//必须转化为 int 才能比较
					var amount=parseInt($(this).prev().val());
					//拿到库存 父容器存储(通过自定义属性) 然后 进行判断 
					var stock=$(this).parent().data('stock');
					if(amount>=stock) return;
					amount++;
					_this.handleMoney($(this),amount);
					/*console.log($(this));*/
					
				});
			},
			input:function(){
				var _this=this;
				this.carMain.on('input','.amount-input',function(){
					var amount=parseInt($(this).val());
					//为空返回1
					if(amount==='')return;
					//非法为1
					if(isNaN(amount)){
						amount=1;
					}
					//和库存比较 (父的div 自定义属性)
					var stock=$(this).parent().data('stock');
					if(amount>=stock){
						amount=stock;
					}
					$(this).val(amount);
					$('.amount-input').blur(function(){
						var amount=$(this).val();
						if(amount===''){
							$(this).val(1);
						}
					});
					//yixiechuli
					_this.handleMoney($(this),amount);
					
				});
			},
			decrease:function(){
				var _this=this;
				this.carMain.on('click','.amount-decrease',function(){
					var amount=parseInt($(this).next().val());
					if(amount<=1) return;
					amount--;
					_this.handleMoney($(this),amount);
				});
			},
			handleMoney:function(obj,amount){
				var money=amount*obj.parents('.cart-goods-item')
				.find('.goods-price').html();
					obj.parents('.cart-goods-item')
					.find('.goods-money').html(money.toFixed(2));
					obj.parent().find('.amount-input').val(amount);
					//改变cart cookie
					var id=obj.parents('.cart-goods-item').data('id');
					this.cart[id].amount=amount;// 找到某一件
					this.setCookie();
					this.handleInfo();
			}, 
			//局部删除
			delete:function(){
				//事件委托
				var _this=this;
				this.carMain.on('click','.delete',function(){
					//that指的是当前的 a
					var that=this;
					/*console.log(that);*/
					layer.confirm('确定删除宝贝吗',function(){
						layer.closeAll();
						//页面删除
						$(that).parents('.cart-goods-item').remove();
						//从cookie  删除 编号 的属性
						var id=$(that).parents('.cart-goods-item').data('id');
						delete _this.cart[id];
						//每删除一次 设置一次cookie
						_this.setCookie();
					});
				});
			},
			//删除选中
			deleteSelect:function(){
				var _this=this;
				$('.cart-option .delete').click(function(){
					var allChecked=_this.carMain.find('input[type=checkbox]:checked');
					if(allChecked.length<=0){
						layer.alert("请选择商品");
						return;
					}
					layer.confirm('确认删除选中的药品吗？',function(){
					allChecked.each(function(){
						layer.closeAll();
						//1.页面上删除
						$(this).parents('.cart-goods-item').remove();
						/*console.log($(this));*/
						//2.cookie删除
						var id = $(this).parents('.cart-goods-item').data('id');
						delete _this.cart[id];
						_this.setCookie();

						//更新总价和全选
						_this.handleInfo();
						$('input.select-all-btn').prop('checked',false);
						});
					});

				});
			},
			select:function(){
				//获取所有被选中的商品
				var _this=this;
				this.carMain.on('change','input[type=checkbox]',function(){
						_this.handleInfo();
					//判断是否需要选中全选按钮 
					//当按钮按到和此刻的按钮一样的时候 说明已经全选 那么给全选选中状态
						var allChecked=_this.carMain.find('input[type=checkbox]:checked');
						var allCheckBox=_this.carMain.find('input[type=checkbox]');
						if(allChecked.length===allCheckBox.length){
							$('input.select-all-btn').prop('checked',true);
						}else{
							$('input.select-all-btn').prop('checked',false);
						}
					
				});
			},
			//全选
			selectAll:function(){
				var _this=this;
				$('input.select-all-btn').click(function(){
					//获取自己的状态  此时返回的是true 和false 
					var status=$(this).prop('checked');
					/*console.log(status);*/
					//商品的选中状态 通过和全选按钮进行融合 选中商品也都选中
					// prop('checked',status(true)) 也就是选中状态
					_this.carMain.find('input').prop('checked',status);
					_this.carMain.find('input').change();//给商品也进行点击改变小计的状态
					
					//全选按钮状态
					$('input.select-all-btn').prop('checked',status);
				});
			},
			//总计费用
			handleInfo:function(){
				var allChecked=this.carMain.find('input[type=checkbox]:checked');
					//商品数量 和小计费用
					var totalNum=0;
					var totalMoney=0;
					//遍历所有选中的商品
					allChecked.each(function(){
						//每有一件选中 就++
						totalNum++;
						var m=$(this).parents('.cart-goods-item')
						.find('.goods-money').html();
						console.log($(this));
						//进行转化
						totalMoney += parseFloat(m);
					}); 
					//判断是否可以结账 也就是让按钮亮起来的js
						if(totalNum > 0){
							$('.go-pay').addClass('can-pay');
						}else{
							$('.go-pay').removeClass('can-pay');
						}
						//更改件数和总
						$('.user-goods-amount').html(totalNum);
						$('.user-goods-money').html(totalMoney.toFixed(2));
			},
			readCookie:function(){
				this.cart=$.cookie('tm-cart') ||'{}';
				this.cart=JSON.parse(this.cart);
			},
			setCookie:function(){
				$.cookie('tm-cart',JSON.stringify(this.cart),{expires:365,path:'/'});
			}
			

		};
		cart.init();
	});
});