define(['jquery','jquery.cookie'],function($){
	//加载需要用到的模块
	

		//读取cookie，判断用户是否登录，填充信息
		var userinfo = $.cookie('userinfo');
		
		//如果有用户信息
		if(userinfo){
			//将json字符串转化为json对象
			userinfo = JSON.parse(userinfo);
			//用户处于登录状态,更改信息
			if(userinfo.login_status){

				$('.qingdenglu').html( userinfo.account +',退出<a href="javascript:;" class="logout"></a>' );
			}else{
				/*$('.qingdenglu').html('您好,欢迎来到我的医药网'+userinfo.account)*/
				$('.qingdenglu').html( userinfo.account + '<a href="login.html">您好,</a><a href="register.html"></a>' );
			}
		}
		console.log(userinfo);
		//退出
		$('.logout').click(function(){
			var info = {
				account: userinfo.account,
				login_status: 0
			};
			$.cookie('userinfo',JSON.stringify(info),{expires: 365,path: '/'});
			location.href = "login.html";
		});
	
});