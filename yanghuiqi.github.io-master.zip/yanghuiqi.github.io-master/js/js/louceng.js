define(['jquery','template'],function($,template){
	$.getJSON('../json/louceng.json',function(data){
	/*	console.log(template);*/
		
		// 楼层加载
		var html1=template('lcfor',{lcc:data});
		$('.lc').html(html1);
		// 楼层js
		var floorNav=$('.floor-nav'),
			realFloor=$('.real-floor'),
			floorItem=$('.floor-nav-item');
			/*console.log(floorNav,realFloor,floorItem)*/
		var ch=document.documentElement.clientHeight;
		$(window).scroll(function(){
			var scrollT=$('body').scrollTop();

			if(scrollT>2013-ch/2){
				floorNav.fadeIn();
			}else{
				floorNav.fadeOut();
			}
			realFloor.each(function(i){
				var h = $(this).outerHeight();
				var t = $(this).offset().top;

				//判断是否为显示的楼层
				if( (t < ch/2 + scrollT)
					 && 
					(t + h > scrollT + ch/2)
				){
					floorItem.eq(i).addClass('active')
						   .siblings().removeClass('active');
					return;
				}
			});
		});
		floorItem.click(function(){
					//每个的下标
					var index = $(this).index();
					//每个楼层的下标的距离顶部的距离
					var t = realFloor.eq(index).offset().top;
					$('html,body').animate({
						scrollTop: t
					});
				});

	
	});
	$('.offside-item .go-top').click(function(){
		$('body,html').animate({scrollTop:0});
	});
	$('.floor-nav-item.topp').click(function(){
		$('body,html').animate({scrollTop:0});
	});
	
});