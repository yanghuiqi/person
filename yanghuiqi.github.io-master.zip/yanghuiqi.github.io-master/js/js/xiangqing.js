require(['../../config'],function(){

	require(['jquery','jquery.cookie','template','layer','jquery.fly'],function($,jquerycookie,template,layer,jqueryfly){
		//放大镜
		var hezi=$('.hezi'),
		filter=$('.filter'),
		largeImg=$('.large-img'),
		hezi=$('.hezi'),
		large=$('.large'),
		area=$('.area')
		ar=$('.ar-right')
		arl=$('.ar-left'),
		areaImg=$('.area img');
	$('.expend').mousemove(function(e){
		
		var lw=hezi.offset().left;
		var tw=hezi.offset().top;
		
		var l=e.pageX-lw-90;
		var t=e.pageY-tw-90;
			/*console.log(l);*/
		l=l<0?0:(l>196?196:l);
		t=t<0?0:(t>196?196:t);

		filter.css({"left":l,"top":t,"display":"block"});
		largeImg.css({"left":-l*2,"top":-t*2});
		large.show();
		
	});
	$('.expend').mouseleave(function(){
		filter.hide();
		large.hide();
	});

	area.on('mouseover','img',function(){
		$(this).addClass('active').siblings().removeClass('active');
		var src=$(this).attr('data-url');
		$('.expend').find('img').attr('src',src);
		large.find('img').attr('src',src);
	});

	var index=0;
	ar.click(function(){
		index++;
		console.log(areaImg);
		if(index > areaImg.length - 5){
			index = areaImg.length - 5;
			return;
		}
		area.animate({
			marginLeft: -index*60
		});
	});
	arl.click(function(){
		index--;
		console.log(areaImg);
		if(index <0){
			index = 0
			return;
		}
		area.animate({
			marginLeft: -index*60
		});
	});

	//选项卡
	$('.tab-text').click(function(){
		$(this).addClass('active').siblings().removeClass('active');
		$('.tab-con-item').eq($(this).index()).show().siblings().hide();
	});

	//回到顶部
	$('.offside-item .go-top').click(function(){
		$('body,html').animate({scrollTop:0});
	});
	
	//lunbo
	var arLeft=$('.leftl'),
		arRight=$('.righte'),
		lunbo=$('.lunbo'),
		li=$('.lunbo li');
	var next=0;
	arRight.click(function(){
		next++;
		console.log(li.length);
		if(next > li.length - 6){
			next = li.length - 6;
			return;
		}
		lunbo.animate({
			marginLeft: -next*188
		});
	});
	arLeft.click(function(){
		next--;
		console.log(arRight);
		if(next <0){
			next = 0
			return;
		}
		lunbo.animate({
			marginLeft: -next*188
		});
	});

	/*
		1加载json
		选中第一个 拿到第一个的id 用id获取库存和价格
		2.事件委托 给li 添加点击事件 选中每一个li 然后获取每一个的id
		给每一个 添加价格和库存
		3.增减操作 找到val() 注意 parseInt转换
	*/

	var detail={
		data:{},
		init:function(){
			var _this=this;
			//先把json加载过来
			$.getJSON('../json/data.json',function(result){
				//用data把 json接收一下
				_this.data=result;
				//加载多个li
				var list=template('type-yao',result);
				$('.color-content').html(list);
				//选中第一个
				var first=$('.color-content li:first');
				first.addClass('selected');
				//拿到此时第一个的价格和库存
				var id=first.data('id');
				//获取第一个分类的编号
				//变量和数字使用[]
				$('.goods-price').html(result.color[id].sale_price);
				$('.stock-num').html(result.color[id].stock);

			});
			//颜色选中
			this.colorSwitch();
			//+ -
			this.increase();
			this.decrease();
			//input 处理
			this.input();
			//加入购物车
			this.addTocart();
		},
		colorSwitch:function(){
			var _this=this;
			$('.color-content').on('click','.tb-con-item',function(){
				$(this).addClass('selected').siblings().removeClass('selected');
				var id=$(this).data('id');
				//获取第一个分类的编号
				//变量和数字使用[]
				$('.goods-price').html(_this.data.color[id].sale_price);
				$('.stock-num').html(_this.data.color[id].stock);

			});
		},
		//数量增加
		increase:function(){
			$('.amount-increase').click(function(){
				//拿到当前的数量
				var amount=parseInt($(this).prev().val());
				//获取库存
				var stock=$('.stock-num').html();//拿到的字符串
				if(amount>=stock) return;
				amount++;//当++ -- 会发生转换
				$(this).prev().val(amount);
			});
		},
		//数量减少
		decrease:function(){
			$('.amount-decrease').click(function(){
				var input=$(this).parent().find('.amount-input');
				var amount=parseInt(input.val());
				if(amount<=1) return;
				amount--;
				input.val(amount);
			});
		},
		input:function(){
			//监听input
			$('.amount-input').on('input',function(){
				var amount=$(this).val();
				if(amount==='')return;
				//656ss=>656 parseInt 会将不是数字的去掉
				amount=parseInt(amount);
				//非法的为1
				if(isNaN(amount)){
					amount=1;
				}
				//判断库存
				var stock=$('.stock-num').html();
				if(amount>=stock){
					amount=stock;
				}
				$(this).val(amount);
			});
			//失焦
			$('.amount-input').blur(function(){
				var amount=$(this).val();
				if(amount===''){
					$(this).val(1);
				}
			});
		},
		addTocart:function(){
			$('.price-info').click(function(e){
				//飞入购物车
				var offset=$('.jinhuodan').offset(),
				flyer= $('<img class="u-flyer" src="../../img/lanrenzhijia.jpg"/>'),
				scrollTop = $(document).scrollTop();
				flyer.fly({
				    start: {
				        left: e.clientX,
				        top: e.clientY
				    },
				    end: {
				        left: offset.left,
				        top: offset.top-scrollTop,
				        width: 20,
				        height: 20
				    }
				});
				//选中的商品 编号
				var goods=$('.tb-con-item.selected');
				/*console.log(goods);*/
				var id=goods.data('id');
				var amount=parseInt($('.amount-input').val());
				//读取cookie
				var cart=$.cookie('tm-cart') || '{}';
				cart=JSON.parse(cart);
				//判断是否已经存在当前商品 给一个自定义属性
				if(!cart[id]){
					//不存在就添加 对象100001：{}
					cart[id]={
						id:id,
						amount:amount
					};
				}else{
					cart[id].amount+=amount;
				}
				
				//重写cookie
				$.cookie('tm-cart',JSON.stringify(cart),{expires:365,path:'/'});
				console.log(JSON.parse($.cookie('tm-cart')));

			});
		}

	}
	detail.init();
});
	});
	