
require(['../../config'],function(){

	//核心工作
	require(['jquery','jquery.cookie'],function($){

		var  accountLogin=$('.account-login'),
		 password=$('.password-login'),
		 btn2=$('.btn2');
		/* console.log(accountLogin,password,btn2);*/
		 btn2.click(function(){
		 	var account = accountLogin.val();
			var psw = password.val();
			//判断是否输入为空
			if(account=='' || psw == ''){
				$('.login-tips').fadeOut(50)
						.fadeIn(50)
						.fadeOut(50)
						.fadeIn(50)
						.animate({
							marginRight:10
						},600,function(){
							$('.login-tips').fadeOut(300);
						});

				return;
			}	
				//使用ajax进行登录
			$.ajax({
				type: 'post',
				url: 'http://10.9.151.199/PC-Project-Admin/login.php',
				data: {
					account: account,
					password: psw
				},
				dataType: 'jsonp',
				success: function(result){
					if(result.status) {
						console.log('登录成功');

						//判断是否需要自动登录
						//if( $('#remember').prop('checked') ){
							var userinfo = {
								account: account,
								login_status: 1
							};
							$.cookie('userinfo',JSON.stringify(userinfo),{expires: 365,path: '/'});
						//}

						//大部分会跳转到首页
						location.href = 'index.html';
					}else{
						console.log('登录失败');
					}
				}
			});
		 });
	});

});


